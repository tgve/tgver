# tgver 0.2.0

* Package now relies on bundled tgve client app's URL variables only 

# tgver 0.1.1

* Added a `NEWS.md` file to track changes to the package.
